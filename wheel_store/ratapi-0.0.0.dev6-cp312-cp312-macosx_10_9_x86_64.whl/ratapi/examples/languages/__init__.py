"""A benchmark for using RAT custom files in three different languages."""
