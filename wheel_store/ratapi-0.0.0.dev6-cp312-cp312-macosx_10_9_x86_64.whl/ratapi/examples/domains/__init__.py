"""Examples for how to use RAT with domains models."""
